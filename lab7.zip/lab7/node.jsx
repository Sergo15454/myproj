import React, { useEffect, useState } from 'react';
import axios from 'axios';

const PostManager = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ title: '', body: '' });

  // Отримання даних (GET)
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(response => {
        setPosts(response.data.slice(0, 5)); // тільки перші 5 для прикладу
      })
      .catch(error => console.error('Error fetching posts:', error));
  }, []);

  // Створення поста (POST)
  const createPost = () => {
    axios.post('https://jsonplaceholder.typicode.com/posts', newPost)
      .then(response => {
        console.log('Post created:', response.data);
        setPosts([response.data, ...posts]);
        setNewPost({ title: '', body: '' });
      })
      .catch(error => console.error('Error creating post:', error));
  };

  // Оновлення поста (PUT)
  const updatePost = (id) => {
    axios.put(`https://jsonplaceholder.typicode.com/posts/${id}`, {
      title: 'Оновлений заголовок',
      body: 'Оновлений текст'
    })
      .then(response => {
        console.log('Post updated:', response.data);
      })
      .catch(error => console.error('Error updating post:', error));
  };

  // Видалення поста (DELETE)
  const deletePost = (id) => {
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(() => {
        console.log('Post deleted');
        setPosts(posts.filter(post => post.id !== id));
      })
      .catch(error => console.error('Error deleting post:', error));
  };

  return (
    <div>
      <h2>Керування постами</h2>

      <input
        type="text"
        placeholder="Заголовок"
        value={newPost.title}
        onChange={e => setNewPost({ ...newPost, title: e.target.value })}
      />
      <input
        type="text"
        placeholder="Текст"
        value={newPost.body}
        onChange={e => setNewPost({ ...newPost, body: e.target.value })}
      />
      <button onClick={createPost}>Створити пост</button>

      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <strong>{post.title}</strong>
            <p>{post.body}</p>
            <button onClick={() => updatePost(post.id)}>Оновити</button>
            <button onClick={() => deletePost(post.id)}>Видалити</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PostManager;
