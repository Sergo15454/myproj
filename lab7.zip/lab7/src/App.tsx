import { useState } from 'react';
import styles from './App.module.css';
import Counter from './components/Counter';

function App() {
    const [count, setCount] = useState(0);

    return (
        <div>
            <h1 className={styles.title}>Лабораторна робота №7</h1>
            <p className={styles.counter}>Лічильник: {count}</p>
            <Counter initialValue={5} />
            <button
                className={styles.button}
                onClick={() => setCount(count + 1)}
            >
                +1
            </button>
        </div>
    ); 
}

export default App;